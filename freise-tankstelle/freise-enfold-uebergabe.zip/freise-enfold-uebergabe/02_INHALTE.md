# Inhalte – Startseite Freise Automatentankstelle

## Stammdaten
- **Name:** Freise Automatentankstelle (Logo „Freise SEESEN“)
- **Adresse:** Kirchberger Str. 16, 38723 Seesen-Münchehof
- **Telefon:** 05381 8511
- **E-Mail:** info@freise-seesen.de
- **Web:** www.freise-seesen.de
- **Geöffnet:** 24 Stunden · 7 Tage die Woche · 365 Tage im Jahr
- **Kraftstoffe:** Diesel, Super E5, Super Plus, AdBlue®
- **Zahlung:** bargeldlos – girocard, Mastercard, Visa, Freise Tankkarte
- **Nicht verwenden:** handelpro, „Zahlung auf Rechnung“, Online-Beantragung von Tank- oder Gutscheinkarten
- **Route planen:** https://www.google.com/maps/search/?api=1&query=Kirchberger+Str.+16,+38723+Seesen

## Menü (Header)
Startseite · Tankkarte · Gutscheinkarten · Tankbeleg anfordern · FAQ · Kontakt · [Button] Route planen

## Hero
- Subheadline: Freise Automatentankstelle in Münchehof
- H1: Einfach tanken. **Rund um die Uhr.**
- Text: Diesel, Super E5, Super Plus und AdBlue® – 24 Stunden am Tag, 7 Tage die Woche. Einfach vorfahren, bargeldlos bezahlen und tanken.
- Buttons: Route planen · So funktioniert's
- Info-Zeile: 24/7 geöffnet | Bargeldlose Zahlung

## Preisleiste
- Aktuelle Kraftstoffpreise – € / Liter · Unsere Preise werden automatisch aktualisiert.
- Diesel · Super E5 · Super Plus · AdBlue® (Werte über Schnittstelle)

## So funktioniert's
- Subheadline: So funktioniert's
- H2: Tanken – einfach und unkompliziert.
- Text: An unserer Automatentankstelle tanken Sie rund um die Uhr. Die Bedienung erfolgt direkt über den Tankautomaten und ist in wenigen Schritten erledigt.

**Schritt 1 – Karte verwenden**
Stecken Sie Ihre Karte in den Kartenschlitz oder halten Sie sie für einige Sekunden vor das NFC-Lesegerät. Folgen Sie anschließend den Anweisungen auf dem Display.
Hinweis: Ihre Bank reserviert dabei einen Betrag, z. B. 80 € oder 150 €. Das ist keine Abbuchung – mehr zur Vorautorisierung.

**Schritt 2 – Zapfsäule auswählen**
Wählen Sie am Automaten die gewünschte Zapfsäule aus und autorisieren Sie die Zahlung.

**Schritt 3 – Tanken**
Karte entnehmen und wie gewohnt tanken. Auf dem Bildschirm wird Ihnen der jeweils nächste Schritt angezeigt.

**Schritt 4 – Beleg entnehmen**
Nach dem Tankvorgang können Sie Ihren Tankbeleg bei Bedarf am Automaten anfordern. Sie bezahlen nur den Betrag, den Sie tatsächlich getankt haben.
Beleg vergessen oder nicht erhalten? [Button] Tankbeleg digital anfordern

## Kraftstoffe
- Subheadline: Kraftstoffe · H2: Tanken, was Sie brauchen.
- Text: An unserer Automatentankstelle erhalten Sie rund um die Uhr eine Auswahl an Kraftstoffen für Pkw, Transporter, Lkw, landwirtschaftliche Fahrzeuge und Maschinen.
- **Diesel:** Für Pkw, Transporter, Lkw, landwirtschaftliche Fahrzeuge und Maschinen.
- **Super E5:** Superbenzin für Pkw und andere Fahrzeuge mit Ottomotor.
- **Super Plus:** Hochoktaniger Ottokraftstoff für Fahrzeuge mit entsprechenden Anforderungen.
- **AdBlue®:** AdBlue® erhalten Sie ebenfalls direkt an unserer Automatentankstelle.
- Jeweils unten: Aktuell: [Preis] € / Liter

## Vorautorisierung
- Subheadline: Vorautorisierung · H2: Ein Betrag auf Ihrer Karte wurde reserviert?
- Fett: Keine Sorge – dabei handelt es sich nicht um eine zusätzliche Abbuchung.
- Text 1: Vor dem Tankvorgang wird bei Kartenzahlung ein festgelegter Höchstbetrag auf Ihrer Karte reserviert, z. B. 80 € oder 150 €. Diese Vorautorisierung dient lediglich dazu, die Zahlung für den anschließenden Tankvorgang sicherzustellen.
- Text 2: Nach dem Tanken wird der tatsächliche Betrag übermittelt und die Reservierung aufgehoben. Die Freigabe erfolgt automatisch durch Ihre Bank und kann je nach Bank 1–2 Werktage dauern. Auf die Dauer haben wir als Tankstellenbetreiber keinen Einfluss.
- Sprechblase: **Sie bezahlen nur den Betrag, den Sie tatsächlich getankt haben.** – Der höhere Betrag ist nur eine Reservierung Ihrer Bank – keine Abbuchung.
- Konto-Karte: SO SIEHT DAS AUF IHREM KONTO AUS · Beispiel
  - Reserviert beim Start – Vorautorisierung, keine Abbuchung – 150,00 €
  - Tatsächlich getankt – Nur dieser Betrag wird abgebucht – 48,60 €
  - Wird wieder freigegeben – Automatisch durch Ihre Bank – 101,40 €
  - Button: Mehr zur Vorautorisierung

## Bezahlen & Service
- Subheadline: Bezahlen · H2: Einfach bargeldlos bezahlen.
- Text: An unserem Tankautomaten stehen Ihnen verschiedene bargeldlose Zahlungsmöglichkeiten zur Verfügung.
- Logos: girocard · Mastercard · Visa · Freise Tankkarte
- Hinweis (kursiv): Bitte beachten Sie, dass es bei Kartenzahlungen zu einer vorübergehenden Vorautorisierung kommen kann.
- Kacheln:
  - **Tankbeleg anfordern** – Beleg verloren oder nicht erhalten? Hier digital nachfordern.
  - **Gutscheinkarten** – Tankgutscheine zum Verschenken – erhältlich direkt bei uns. Einfach anfragen.
  - **Hilfe bei Problemen** – Karte abgelehnt, Zapfsäule gibt nicht frei? So erreichen Sie uns.

## FAQ
- Subheadline: FAQ · H2: Häufige Fragen
- Text: Die meisten Fragen drehen sich um den Ablauf am Automaten und die Reservierung auf der Karte. Hier die Antworten.
- Box: **Ihre Frage ist nicht dabei?** Halten Sie Datum, ungefähre Uhrzeit, Tankbetrag und Zahlungsart bereit. [Button] Kontakt aufnehmen

1. **Wie funktioniert das Tanken am Tankautomaten?** – Karte am Automaten verwenden, den Anweisungen auf dem Display folgen, Zapfsäule auswählen und anschließend tanken. Die einzelnen Schritte werden Ihnen direkt am Automaten angezeigt.
2. **Warum wird ein höherer Betrag auf meiner Karte reserviert?** – Dabei handelt es sich um eine Vorautorisierung. Vor dem Tankvorgang wird ein Höchstbetrag reserviert, um die Zahlungsfähigkeit der verwendeten Karte zu bestätigen. Tatsächlich abgerechnet wird ausschließlich der getankte Betrag.
3. **Warum sehe ich zwei Beträge auf meinem Konto?** – Neben dem tatsächlichen Tankbetrag kann vorübergehend noch der reservierte Vorautorisierungsbetrag angezeigt werden. Es handelt sich dabei nicht um eine zweite Abbuchung.
4. **Wann wird die Reservierung wieder aufgehoben?** – Die Freigabe erfolgt automatisch durch Ihre Bank bzw. Ihr Kreditkartenunternehmen und kann je nach Bank 1–2 Werktage dauern. Auf die Dauer der Reservierung haben wir keinen Einfluss.
5. **Kann ich rund um die Uhr tanken?** – Ja. Unsere Automatentankstelle steht Ihnen 24 Stunden am Tag und 7 Tage die Woche zur Verfügung.
6. **Welche Kraftstoffe kann ich tanken?** – An unserer Automatentankstelle erhalten Sie Diesel, Super E5, Super Plus und AdBlue®.
7. **Wie erhalte ich einen Tankbeleg?** – Nach Abschluss des Tankvorgangs können Sie Ihren Beleg am Tankautomaten anfordern. Falls Sie keinen erhalten haben, fordern Sie ihn über unser Formular digital an.
8. **Was mache ich bei einer Störung?** – Rufen Sie uns an unter 05381 8511 oder schreiben Sie an info@freise-seesen.de.

## Tankkarte (Banner)
- Subheadline: Sind Sie öfter hier? · H2: Die Freise Tankkarte.
- Text: Für Betriebe, Landwirte und alle, die regelmäßig bei uns tanken. Auch Gutscheinkarten zum Verschenken erhalten Sie direkt bei uns.
- Fett: Interessiert an einer Tankkarte oder Gutscheinkarte? Sprechen Sie uns an.
- Anrufen: 05381 8511 · E-Mail: info@freise-seesen.de
- Oder schreiben Sie uns über das Kontaktformular.

## Standort-Leiste
- Adresse: Kirchberger Str. 16 / 38723 Seesen-Münchehof – [Button] Route planen
- Geöffnet: 24 Stunden / 7 Tage die Woche – Jetzt geöffnet
- Kontaktdaten: 05381 8511 / info@freise-seesen.de – [Button] Nachricht schreiben

## Footer
- Text: Ihre Automatentankstelle in Seesen-Münchehof. Diesel, Super E5, Super Plus und AdBlue® – rund um die Uhr.
- Kontakt: Adresse · 24 Stunden · 7 Tage die Woche · 05381 8511 · info@freise-seesen.de
- **Tankstelle:** Aktuelle Preise · So funktioniert's · Kraftstoffe · Vorautorisierung · FAQ
- **Service:** Tankkarte · Gutscheinkarten · Tankbeleg anfordern · Standort · Kontakt
- **Formular „Schreiben Sie uns“:** Name* · E-Mail* · Ihr Anliegen* (Tankkarte beantragen / Gutscheinkarte anfordern / Tankbeleg anfordern / Frage & Rückmeldung) · Nachricht (Platzhalter: „Ihre Nachricht – bei Tankbelegen bitte Datum, Uhrzeit, Betrag und Zahlungsart angeben.“) · Checkbox*: „Ich habe die Datenschutzerklärung gelesen und bin damit einverstanden, dass meine Angaben zur Bearbeitung meiner Anfrage gespeichert und verarbeitet werden.“ · Button: Absenden
- Socket: © 2026 Freise Automatentankstelle · Impressum · Datenschutz

## Bilder (Ordner `medien/`)
| Datei | Einsatz |
|---|---|
| hero-zapfpistole.jpg | Hero-Hintergrund |
| block-bezahlen.jpg | Schritt 1 |
| card-hilfe.jpg | Schritt 2 |
| step-tanken.jpg | Schritt 3 |
| block-beleg.jpg | Schritt 4 |
| pay-girocard.png, pay-mastercard.png, pay-visa.png | Zahlungslogos |
| tankkarte-dreht.gif | Tankkarten-Banner |
| karte-grau.jpg | Kartenbild (falls kein Google Maps) |
| tankstelle.jpg | Foto in der Standort-Leiste |
