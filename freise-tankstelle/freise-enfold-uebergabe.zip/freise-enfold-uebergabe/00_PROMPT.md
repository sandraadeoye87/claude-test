# Prompt für die Umsetzung in Enfold

> Diesen Text in die neue Sitzung kopieren und den Ordner `freise-enfold-uebergabe` mit anhängen.

---

Setze die fertig abgestimmte Startseite der **Freise Automatentankstelle** (Seesen-Münchehof) in WordPress mit dem Theme **Enfold** um. Ich bin im WordPress-Backend angemeldet; arbeite in meinem Browser.

## Unterlagen in diesem Paket

| Datei / Ordner | Inhalt |
|---|---|
| `01_BAUPLAN.md` | Abschnitt für Abschnitt: Aufbau, Enfold-Elemente, Maße, Farben, Icons, Verhalten auf dem Handy |
| `02_INHALTE.md` | Alle Texte, Kontaktdaten, Menüs, Formularfelder |
| `entwurf/index.html` | Der abgestimmte Entwurf (im Browser öffnen). **Das ist die verbindliche Vorlage für Optik und Abstände.** |
| `entwurf/Freise-Startseite-Entwurf.pdf` | Derselbe Entwurf als PDF (Desktop) |
| `medien/` | Alle Bilder, Zahlungslogos, Kartenbild, Tankkarten-GIF – für die Mediathek |
| `logo/` | Logo als SVG (schwarz und weiß) und Original-PDF |
| `icons/freise-iconset-01.zip` | Die Icons als SVG. **Sie sind bereits als Iconfont „Freise Iconset 01“ in Enfold hinterlegt** – nicht erneut hochladen. |
| `referenz/` | Original-Texte des Kunden, Säulenschild (Gestaltungsreferenz), Charg-Theme (Stilreferenz, die dem Kunden gefällt) |

## Ausgangslage im WordPress

- In Enfold habe ich die **Theme-Einstellungen einer anderen Website desselben Kunden importiert**, um das System grundlegend aufzusetzen. **Prüfe deshalb alle Enfold-Einstellungen** (Allgemeines Styling, Farben, Schriften, Header, Footer, Socket, Sidebar, Blog, Datenschutz/Cookies, Performance, Quick CSS usw.) und passe sie an dieses Projekt an. Nichts davon ungeprüft übernehmen.
- Ansonsten ist die Seite **jungfräulich**: keine Seiten, keine Menüs, keine Inhalte.

## Arbeitsweise

1. **Zuerst nur lesen und berichten, nichts ändern:** Theme-Einstellungen durchgehen, das vorhandene **Quick CSS** gründlich lesen und mir kurz zusammenfassen, was du vorfindest und was du anpassen willst.
2. **Vor dem ersten Ändern ein Backup** der Enfold-Einstellungen exportieren (Enfold → Import/Export).
3. Die Startseite als **Entwurf** aufbauen, nicht veröffentlichen. Veröffentlichen nur nach meiner Freigabe.
4. Nach jedem großen Abschnitt kurz Bescheid geben und Desktop **und** Handy-Ansicht prüfen.
5. Bei Unklarheiten fragen statt raten.

## Regeln für das CSS (sehr wichtig)

- **Mein vorhandenes Quick CSS ist der Maßstab.** Schau dir genau an, wie ich es schreibe (Aufbau, Benennung, Kommentare, Reihenfolge) und orientiere dich stark daran.
- **Vorhandene Klassen nutzen**, wenn sie passen; sie dürfen dafür umgeschrieben werden. Keine doppelten Klassen für dasselbe.
- **Keine CSS-Variablen** (`var(--…)`, `:root`) – nur feste Werte.
- **Kein `:not()`** in Selektoren.
- **`!important` nur, wenn es wirklich nötig ist** (z. B. gegen Enfold-Inline-Styles).
- Die einzelnen Styles **mit Kommentaren voneinander trennen**.
- **Mobile Anpassungen nicht gesammelt am Ende**, sondern jeweils **direkt beim zugehörigen Style** (die `@media`-Regel steht unter dem Block, den sie betrifft) – so wie es in meinem Quick CSS jetzt schon ist.
- **Achte darauf, an welchen Breiten ich Spalten auf volle Breite umbrechen lasse** (Breakpoints in meinem CSS und in den Enfold-Spalteneinstellungen) und übernimm diese Logik. Mobile Optimierung hat hohe Priorität.
- Das CSS im Entwurf (`entwurf/index.html`) ist nur die **Vorlage für Werte und Optik** – es nutzt Variablen und `:not()` und darf **nicht** 1:1 kopiert werden.
- **Am Ende alles CSS entfernen, das nicht verwendet wird** – auch Reste aus der importierten Konfiguration.

## Sonstige Vorgaben

- **Schrift:** Poppins, **lokal** eingebunden (DSGVO), nicht von Google laden.
- **Icons:** nur aus „Freise Iconset 01“ (Zuordnung im Bauplan).
- **Inhalte:** Tankkarte und Gutscheinkarten gibt es **nur vor Ort** – es gibt **keine Online-Beantragung** und **keine Zahlung auf Rechnung**. Die Firma **handelpro** taucht nirgends auf.
- **Preise:** Die Preisleiste ist vorbereitet; die Schnittstelle des Anbieters kommt später. Bis dahin Platzhalter, der **nicht live gehen darf** (siehe Bauplan).

## Vorab mit mir klären

1. **Karte:** Enfold-Element „Google Maps“ in Graustufen (interaktiv, lädt erst nach Einwilligung) oder das Kartenbild aus `medien/karte-grau.jpg` wie im Entwurf?
2. **Formular:** Enfolds eigenes Kontaktformular oder ein Plugin (z. B. Contact Form 7)?
3. **Child-Theme:** Ist eins aktiv? (Nötig für das kleine Skript zur Formular-Vorauswahl.)
4. **Menü:** Sollen die Menüpunkte vorerst auf Abschnitte der Startseite zeigen, oder legen wir die Unterseiten (Tankkarte, Gutscheinkarten, Tankbeleg anfordern, FAQ, Kontakt, Impressum, Datenschutz) gleich als leere Seiten an?
