# Bauplan – Startseite Freise Automatentankstelle

Verbindliche Vorlage ist `entwurf/index.html` (im Browser öffnen, Fensterbreite ändern, um das Verhalten auf dem Handy zu sehen). Alle Werte hier sind feste Werte für das Quick CSS.

---

## 1. Grundwerte

### Farben
| Name | Wert | Verwendung |
|---|---|---|
| Schwarz | `#0e0f11` | Texte, dunkle Abschnitte, Footer, Linien der Schritte |
| Schwarz 2 | `#1b1d21` | Karte „So sieht das auf Ihrem Konto aus“ |
| Schwarz 3 | `#2a2d32` | Sprechblase, Footer-Formularfelder, Kreise hinter Footer-Icons |
| Tiefschwarz | `#000000` | Zusatzleiste ganz oben |
| Rot | `#ce1729` | Akzent, Buttons, Punkte, Icons (Logo-Rot) |
| Rot dunkel | `#a50f1f` | Hover roter Buttons |
| Rot hell | `#ff4d5e` | nur Betrag „48,60 €“ in der dunklen Konto-Karte |
| Weiß | `#ffffff` | Hintergrund |
| Hellgrau | `#f3f2f2` | Abschnitte „Kraftstoffe“ und „FAQ“, Hinweisbox Schritt 1, aktiver Menüpunkt |
| Linie | `#e4e1e1` | Trennlinien, Rahmen |
| Text grau | `#5b5859` | Fließtext auf Hell |
| Text grau auf Dunkel | `#a9a6a7` | Fließtext auf Dunkel |
| Grün | `#22b35e` / Text `#1a8a4a` | „Jetzt geöffnet“ |
| Kartenfläche | `#e8e8e8` | Hintergrund hinter dem Kartenbild |

### Schrift: Poppins (lokal)
| Element | Größe | Stärke | Sonstiges |
|---|---|---|---|
| Fließtext | 16px | 400 | Zeilenhöhe 1.7 |
| Lead-Text unter Überschriften | 17px | 400 | Text grau |
| H1 (Hero) | 62px Desktop → 38px Handy (fließend) | 800 | Zeilenhöhe 1.12, Buchstabenabstand −0.03em; 2. Zeile rot |
| H2 | 40px → 28px | 800 | Zeilenhöhe 1.12, −0.02em |
| Schritt-Titel groß | 29px → 24px | 800 | |
| Schritt-Titel klein / Kraftstoff-Name | 22–24px | 800 | |
| **Subheadline („Überzeile“)** | 14px | **400 (nicht fett)** | VERSALIEN, Buchstabenabstand 1px, rot; davor roter Punkt 11px. Auf dunklem Grund: Text weiß, Punkt rot |
| Buttons | **15px überall** | 600 | |

### Buttons
- Pillenform (`border-radius: 999px`), **2px Rahmen** in Button-Farbe, Schrift 15px/600, Symbol links 18px.
- Varianten: **Rot** (rot gefüllt, Hover dunkelrot) · **Weiß** (weiß gefüllt, Hover schwarz) · **Kontur hell** (2px weiß, transparent – auf Dunkel) · **Kontur dunkel** (2px schwarz – auf Hell).
- Höhe 54px Standard; kleiner im Header (46px), Standort-Leiste (42px), Formular (44px), Schritt 4 (46px).

### Rundungen, Container, Abstände
- Inhaltsbreite **1180px**, seitlicher Rand 20px.
- Abschnitte: **110px** oben/unten, ab ≤ 760px **72px**.
- Karten/Leisten: Radius **22px**. Bilder und Banner: **nur eine Ecke** rund, **40px** (oben links oder oben rechts – siehe Abschnitte).

### Breakpoints im Entwurf (mit deinem Quick CSS abgleichen)
| Breite | Was passiert |
|---|---|
| ≤ 1160px | Header: Burger-Menü, Button „Route planen“ ausgeblendet |
| ≤ 980px | Preisleiste 2-spaltig; Kraftstoffe 2-spaltig; Standort-Leiste 2-spaltig (Foto oben volle Breite) |
| ≤ 900px | Schritte, Vorautorisierung, Bezahlen, FAQ: einspaltig |
| ≤ 860px | Tankkarten-Banner untereinander; Kartenbild als eigener Streifen |
| ≤ 760px | Abschnittsabstand 72px |
| ≤ 700px | Footer einspaltig |
| ≤ 560 / 520 / 460px | Formular-Felder untereinander; Kraftstoffe/Standort einspaltig; Preise kleiner |

### Icons – „Freise Iconset 01“ (bereits in Enfold)
| Icon | Einsatz |
|---|---|
| uhr | Hero „24/7 geöffnet“, Footer „Geöffnet“ |
| karte | Hero „Bargeldlose Zahlung“ |
| route | Buttons „Route planen“ |
| lkw | Kraftstoff Diesel |
| tropfen | Super E5, Super Plus |
| zapfsaeule | AdBlue® |
| beleg | Kachel „Tankbeleg anfordern“, Button Schritt 4 |
| geschenk | Kachel „Gutscheinkarten“ |
| hilfe | Kachel „Hilfe bei Problemen“ |
| pfeil-rechts | rechts in den Bezahlen-Kacheln |
| telefon, email | Tankkarten-Banner, Standort-Leiste, Footer |
| standort | Footer „Adresse“ |
| haken, plus, pfeil-unten, menue | Listen, FAQ, Dropdown, Handy-Menü (falls per Icon gelöst) |

---

## 2. Abschnitte (von oben nach unten)

### 2.1 Zusatzleiste + Header
- **Zusatzleiste** (Enfold „Header-Zusatzleiste“), Hintergrund `#000`, 13px: links grüner pulsierender Punkt + **„Jetzt geöffnet“** (weiß, fett) + „· 24 Stunden · 7 Tage die Woche“ (grau); rechts „Wir helfen Ihnen gerne: **05381 8511**“ (auf dem Handy ausblenden).
- **Header weiß**, sticky, Höhe 82px, unten 1px Linie + leichter Schatten. Logo **schwarz, 240px breit** (Handy 190px).
- **Menü:** 14px/600 schwarz; Hover rot; aktiver Punkt: rote Linie 3px **oben** + Hintergrund hellgrau.
- **Letzter Menüpunkt als roter Button** „Route planen“ mit Icon `route`.
- Handy-Menü: weiß, Einträge mit Trennlinien.

### 2.2 Hero
- Color Section mit Hintergrundbild `hero-zapfpistole.jpg` (Position ca. 62 % horizontal), **Verlauf von links**: 95 % → 80 % → 25 % → 15 % Deckkraft Schwarz. Auf dem Handy dunkler.
- Abstand innen: 120px oben, 160px unten (Platz für die Preisleiste).
- Inhalt links, max. ca. 600px breit: Subheadline „Freise Automatentankstelle in Münchehof“ (weiß, roter Punkt) · H1 „Einfach tanken. / **Rund um die Uhr.**“ (2. Zeile rot) · Lead weiß 86 % · Buttons **Rot „Route planen“** + **Kontur hell „So funktioniert’s“** · Info-Zeile (keine Buttons!): Icon `uhr` + „24/7 geöffnet“ | dünne Trennlinie | Icon `karte` + „Bargeldlose Zahlung“, Text 15px/400, Icons rot 20px.

### 2.3 Preisleiste (Code Block)
- Liegt **über der Unterkante des Hero** (−86px nach oben verschoben), weiß, Radius 22px, Schatten.
- Spalten: rotes Feld „**Aktuelle Kraftstoffpreise**“ / „€ / Liter · Unsere Preise werden automatisch aktualisiert.“ + 4 Preiszellen (Diesel, Super E5, Super Plus, AdBlue®), getrennt durch Linien.
- Preis: 44px/800, **dritte Nachkommastelle hochgestellt und rot** (1,68⁹), dahinter klein „€“.
- ≤ 980px: rotes Feld volle Breite oben, Preise 2 × 2. ≤ 460px: Preise 34px.
- **Schnittstelle:** Preise kommen später vom Anbieter. Code so anlegen, dass nur die Datenquelle ersetzt wird. **Platzhalterpreise dürfen nicht live gehen** – bis dahin Leiste ausblenden oder Hinweis zeigen. Dieselben Preise erscheinen auch in den Kraftstoff-Karten („Aktuell: …“).

### 2.4 So funktioniert’s (Schritte mit Linie)
Weißer Abschnitt. Aufbau:
1. **Zeile 1 (2 Spalten, Abstand 80px):** links Subheadline „So funktioniert’s“, H2 „Tanken – einfach und unkompliziert.“, Lead, darunter direkt **Schritt 1** (Subheadline „Schritt 1“, Titel „Karte verwenden“, Text, graue Hinweisbox mit „!“-Kreis: Reservierung 80/150 € + Link „mehr zur Vorautorisierung“). Rechts: oben roter Punkt **„1“** (50px, weiße Zahl, 6px weißer Ring) mit **schwarzer Linie 5px** nach unten zum Bild `block-bezahlen.jpg` (Seitenverhältnis 1 : 0,9, **Ecke oben links 40px rund**). Linie füllt die Höhe bis zum Bild.
2. **Verbindung zu Schritt 2:** Linie 5px schwarz von der Bildmitte rechts nach unten, Bogen (Radius 40px), waagerecht nach links, Bogen, nach unten zur Bildmitte links. In der Mitte der Waagerechten roter Punkt **„2“**.
3. **Zeile 2 (2 Spalten):** Schritt 2 „Zapfsäule auswählen“ (Bild `card-hilfe.jpg`, 16:10, Ecke oben links rund) und Schritt 3 „Tanken“ (Bild `step-tanken.jpg`, 16:10, Ecke oben rechts rund). Zwischen den Bildern auf halber Höhe waagerechte Linie mit Punkt **„3“**. Unter jedem Bild: Subheadline, Titel, Text. **36px Abstand** bis zur nächsten Linie.
4. **Verbindung zu Schritt 4:** wie oben (rechts → links), Punkt **„4“**.
5. **Zeile 3:** links Bild `block-beleg.jpg` (Ecke oben rechts rund), rechts Schritt 4 „Beleg entnehmen“ + Text, darunter „Beleg vergessen oder nicht erhalten?“ und **roter Button** „Tankbeleg digital anfordern“ (Icon `beleg`) → springt zum Formular und wählt das Anliegen „Tankbeleg anfordern“ vor.
- **Handy (≤ 900px):** alles einspaltig, Bild über dem Text (bei Schritt 1 unter dem Text), zwischen den Schritten eine senkrechte Linie mit nummeriertem Punkt.

### 2.5 Kraftstoffe
- Hellgrauer Abschnitt. Kopf 2-spaltig: links Subheadline + H2 „Tanken, was Sie brauchen.“, rechts Lead.
- 4 weiße Karten (Radius 22px, Abstand 22px): roter Kreis 64px mit weißem Icon, Name (24px/800), Text, unten Linie + „Aktuell: **1,68⁹** € / Liter“. Hover: Karte wird schwarz, Text weiß/grau, hebt sich 6px.
- ≤ 980px 2-spaltig, ≤ 520px einspaltig.

### 2.6 Vorautorisierung
- Schwarzer Abschnitt, 2 Spalten (Abstand 80px).
- Links: Subheadline, H2 „Ein Betrag auf Ihrer Karte wurde reserviert?“, fetter Satz „Keine Sorge – …“, zwei Absätze, **Sprechblase** (Hintergrund `#2a2d32`, Radius 14px, Ecke unten links spitz, rotes Anführungszeichen oben rechts).
- Rechts: Karte `#1b1d21`, Radius 22px: Kopf „SO SIEHT DAS AUF IHREM KONTO AUS“ + Pille „Beispiel“; drei Zeilen mit Balken (16px hoch, rund):
  - Reserviert beim Start – 150,00 € – Balken 100 % **schraffiert** (weiß 32 % / 12 %)
  - Tatsächlich getankt – **48,60 €** (rot hell) – Balken 32,4 % rot
  - Wird wieder freigegeben – 101,40 € – **gestrichelter Rahmen** ab 32,4 %
  - Button Kontur hell „Mehr zur Vorautorisierung“ → FAQ
- **Balken animieren beim Reinscrollen** nacheinander (0 s / 0,7 s / 1,4 s, je 1,2 s). Enfold „Progress Bars“ oder Code Block.

### 2.7 Bezahlen & Service
- Weißer Abschnitt, 2 Spalten.
- Links: Subheadline „Bezahlen“, H2, Lead, **Logoreihe ohne Button-Optik**: girocard, Mastercard, Visa, Freise Tankkarte (kleine schwarze Karte mit weißem Balken und rotem Punkt) – jeweils Logo oben, Name klein darunter, dünne senkrechte Trennlinien. Darunter kursiver Hinweis zur Vorautorisierung.
- Rechts: 3 Kacheln (weiß, 1px Rahmen, Radius 16px): schwarzes Quadrat (60px, Radius 12px) mit weißem Icon · Titel 19px/700 + Text · roter Pfeil rechts. Hover: Rahmen schwarz, 4px nach rechts.
  - „Tankbeleg anfordern“ → Formular, Anliegen vorgewählt
  - „Gutscheinkarten“ → Formular, Anliegen „Gutscheinkarte anfordern“
  - „Hilfe bei Problemen“ → Kontakt

### 2.8 FAQ
- Hellgrauer Abschnitt, 2 Spalten (links schmaler, mitlaufend/sticky).
- Links: Subheadline, H2 „Häufige Fragen“, Lead, schwarze Box „Ihre Frage ist nicht dabei?“ + Text + roter Button „Kontakt aufnehmen“.
- Rechts: Accordion, oben **4px schwarze Linie**, Einträge mit 1px Linie, Frage 18px/700, rechts runder Plus-Knopf (weiß), geöffnet: Knopf rot mit weißem ×. Erster Eintrag offen.
- Unten **viel Abstand** (ca. 530px), weil das Tankkarten-Banner von unten in den Abschnitt hineinragt.

### 2.9 Tankkarten-Banner + Karte + Standort-Leiste
- Bereich mit Kartenbild `karte-grau.jpg` als Hintergrund (**cover**, Position 50 % 48 %) – oder Enfold Google Maps in Graustufen (Entscheidung offen).
- **Banner** (2 Spalten, Ecke oben rechts 70px rund, Schatten) ragt **440px nach oben** in den FAQ-Abschnitt:
  - Links schwarz mit roter schräger Bahn, darin die drehende Tankkarte (`tankkarte-dreht.gif` oder CSS).
  - Rechts rot: Subheadline „Sind Sie öfter hier?“ (weiß), H2 „**Die Freise Tankkarte.**“, Text, Trennlinie, fett „Interessiert an einer Tankkarte oder Gutscheinkarte? Sprechen Sie uns an.“, dann Telefon und E-Mail (weißer Kreis 52px mit rotem Icon, Bezeichnung 14px/400, Wert 18px/700), darunter „Oder schreiben Sie uns über das **Kontaktformular**.“
- **Viel Platz** zwischen Banner und Leiste (ca. 380px), damit die rote Markierung „Tankstelle Freise“ auf der Karte sichtbar ist.
- **Standort-Leiste** (wie die Preisleiste, weiß, Radius 22px), **50px über dem unteren Rand**:
  - Spalten: Foto `tankstelle.jpg` (nimmt den Restplatz) | Adresse | Geöffnet | Kontaktdaten – Textspalten so breit wie ihr Inhalt, **links und rechts je 44px** bis zur Trennlinie.
  - Inhalte **oben ausgerichtet**; Bezeichnung 13px/**400**, Versalien; Werte 16px/700, Zeilenhöhe 1.6.
  - Unterste Zeile auf einer Höhe: roter Button „Route planen“ | grünes „Jetzt geöffnet“ (15px/600) | Kontur-Button „Nachricht schreiben“ → Formular.
  - Kontaktdaten mit kleinen roten Icons `telefon` und `email` vor dem Text.
  - ≤ 980px: Foto oben, 2 × 2; ≤ 520px: einspaltig. ≤ 860px: Kartenbild als eigener Streifen (340px) zwischen Banner und Leiste.

### 2.10 Footer
- Oben 6px rote Linie. Schwarz, 3 Spalten (1,1 : 0,6 : 1,3, Abstand 60px), alle Spalten gleich hoch.
- **Spalte 1:** Logo weiß **270px**, kurzer Satz, Kontaktzeilen (grauer Kreis 38px mit rotem Icon + Text **nicht fett**, weiß): Adresse, Geöffnet, Telefon, E-Mail.
- **Spalte 2:** Menüs **untereinander** – „Tankstelle“ und „Service“; Überschriften im **Subheadline-Stil** (Punkt, Versalien, 14px/400, weiß).
- **Spalte 3:** Formular **ohne Kasten**, Überschrift „Schreiben Sie uns“ im Subheadline-Stil; Felder Hintergrund `#2a2d32`, weiße Schrift, Radius 8px, 1px Rahmen beim Fokus; Platzhalter statt Feldbeschriftung; Nachrichtenfeld wächst, damit das Formular so hoch ist wie die anderen Spalten; Datenschutz-Checkbox klein; roter Button „Absenden“.
- **Socket:** „© 2026 Freise Automatentankstelle“ links, „Impressum · Datenschutz“ rechts.
- ≤ 1060px: Formular volle Breite unter Spalte 1 + 2; ≤ 700px: alles untereinander.

---

## 3. Kleine Skripte
- **Formular-Vorauswahl:** Links mit Anliegen (Tankbeleg, Gutscheinkarte, Tankkarte) setzen beim Klick das Dropdown. Ohne Skript funktionieren die Links trotzdem.
- **Balken-Animation** der Vorautorisierung (falls nicht über Enfold „Progress Bars“).
- **Preisleiste** mit späterer Schnittstelle.
- Alles mit `prefers-reduced-motion` respektieren.
